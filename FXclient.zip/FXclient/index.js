import downloadGame from "./download.js";
console.log("Building Quadz Client");
await downloadGame();
import("./build.js");